from reactpy import component, html
@component
def LoRATrainerPane():
    return html.div(html.h2("LoRA Trainer"))
