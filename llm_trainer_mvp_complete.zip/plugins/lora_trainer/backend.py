class LoRATrainerNode:
    """LoRA fine‑tune node (stub)."""
    def run(self, dataloader, **kwargs):
        return {"status": "ok"}
