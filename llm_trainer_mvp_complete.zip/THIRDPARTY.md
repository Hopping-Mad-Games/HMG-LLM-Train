# Third‑party dependencies

| Package | Version | License |
|---------|---------|---------|
| reactpy | 2.0b2 | MIT |
| fastapi | 0.111 | MIT |
| accelerate | 0.29 | Apache‑2.0 |
| peft | 0.11 | Apache‑2.0 |
| bitsandbytes | 0.43 | MIT |
| tailwindcss | 3.5 | MIT |
| react‑flow | 12.19 | MIT |
| d3‑force | 7.2 | BSD‑3 |
