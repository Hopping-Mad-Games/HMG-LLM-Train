# plugins/lora_trainer

Plug‑in directories—each is self‑contained and adds backend nodes + optional UI.
