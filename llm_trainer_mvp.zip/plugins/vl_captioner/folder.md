# plugins/vl_captioner

Plug‑in directories—each is self‑contained and adds backend nodes + optional UI.
