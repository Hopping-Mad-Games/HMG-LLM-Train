# ui/reactpy_app/components

User‑facing interface implemented with ReactPy mounted on FastAPI.
