# ui/assets/styles

User‑facing interface implemented with ReactPy mounted on FastAPI.
