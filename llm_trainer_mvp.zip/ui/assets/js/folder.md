# ui/assets/js

User‑facing interface implemented with ReactPy mounted on FastAPI.
