# datasets

Small example corpora used in smoke tests and demos.
