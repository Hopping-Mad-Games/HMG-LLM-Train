# docs

Long‑form documentation, diagrams, and contribution guides.
