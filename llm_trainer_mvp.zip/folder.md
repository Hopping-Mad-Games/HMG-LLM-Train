# root

Directory for project resources.
