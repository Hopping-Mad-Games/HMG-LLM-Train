# core/trainers

Python packages that implement the training engine: scheduler, data I/O, trainer loops, and export utilities.
