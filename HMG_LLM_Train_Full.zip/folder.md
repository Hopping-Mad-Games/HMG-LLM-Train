# Repository root

Key docs:
- README.md (overview)
- LICENSE (AGPL‑3)
- NOTICE (attribution)
- THIRDPARTY.md (dependency licenses)
- docs/ (architecture, quickstart, plugin guide, API reference)
