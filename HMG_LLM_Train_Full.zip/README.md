# 🦙 HMG-LLM-Train (MVP)

Local‑first, plug‑in‑based LLM training stack with a **ReactPy + FastAPI** UI, LoRA/QLoRA backend, and AGPL‑3 licensing.

## Highlights
* Graph‑style workflow editor (inspired by ComfyUI)
* One‑click LoRA/QLoRA for 7‑13 B models on consumer GPUs
* Pure‑Python UI (no JS build chain) → hot‑reload
* Extensible via drop‑in `plugins/<name>/`
* Exports GGUF, Safetensors, ONNX
* Ships with Docker Compose files for NVIDIA, ROCm & CPU

For full architecture see `docs/ARCHITECTURE.md`.

## Quick start

```bash
git clone https://github.com/Hopping-Mad-Games/HMG-LLM-Train.git
cd HMG-LLM-Train
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
./scripts/dev.sh
```

Open <http://localhost:8000> and follow `docs/QUICKSTART.md`.

## License & attributions

This repo is **AGPL‑3.0‑or‑later** (see `LICENSE`).

| Inspiration (no code copied) | License |
|------------------------------|---------|
| LLaMA‑Factory | Apache‑2.0 |
| text‑generation‑webui | AGPL‑3.0 |
| ComfyUI | MIT |

Third‑party runtime/development libraries are catalogued in `THIRDPARTY.md`.
