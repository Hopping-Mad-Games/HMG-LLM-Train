# Third‑party dependencies

| Package | Version | License | Scope |
|---------|---------|---------|-------|
| reactpy | 2.0.0b2 | MIT | UI |
| fastapi | 0.111 | MIT | HTTP/WS |
| accelerate | 0.29 | Apache‑2.0 | Training |
| peft | 0.11 | Apache‑2.0 | LoRA |
| bitsandbytes | 0.43 | MIT | 4‑bit quant |
| tailwindcss (CDN) | 3 | MIT | Styling |
| react‑flow (CDN) | 12 | MIT | Graph canvas |
| d3‑force (CDN) | 7 | BSD‑3‑Clause | Layout |
| pytest | 8.2 | MIT | Dev |
| mkdocs‑material | 9.5 | MIT | Docs |
| cypress | 13 | MIT | E2E UI |
