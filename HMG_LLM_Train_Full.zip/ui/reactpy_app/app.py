# SPDX-License-Identifier: AGPL-3.0-or-later
from fastapi import FastAPI
from reactpy import component, html
from reactpy.backend.fastapi import configure

fastapi_app = FastAPI()

@component
def Index():
    return html.div(html.h1("HMG‑LLM‑Train dashboard"))

configure(fastapi_app, Index)
