# SPDX-License-Identifier: AGPL-3.0-or-later
class LoRATrainerNode:
    def __init__(self, **cfg):
        self.cfg = cfg
    async def run(self, dataloader):
        yield {"loss": 1.23}
