REST & WebSocket endpoints:
- POST /api/jobs
- GET /api/jobs/{id}
- WS /ws/metrics/{id}
