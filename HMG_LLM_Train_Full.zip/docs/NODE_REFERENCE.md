Tables for built‑in nodes and their ports as drafted earlier.
