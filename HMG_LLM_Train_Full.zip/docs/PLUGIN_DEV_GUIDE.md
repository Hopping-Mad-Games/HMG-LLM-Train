Full guide in previous chat – omitted here for brevity.
