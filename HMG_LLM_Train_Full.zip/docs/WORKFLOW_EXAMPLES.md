Examples of training graphs (LoRA text, VLM captioner) – as drafted earlier.
