Contributing guidelines, license checklist, coding style – see earlier.
