# 🏗️ Architecture

```
ReactPy UI  ←─────→  FastAPI Gateway  ←─────→  Core Engine  ←────→  Plug‑ins
(graph)                  |  WS/REST                   |              |
```

* **ReactPy UI** – Pure‑Python components, rendered as a Next.js bundle; includes graph canvas (react‑flow), config drawers, live metrics plot.
* **FastAPI gateway** – Exposes `/api/jobs`, `/api/artifacts`, WebSocket `/ws/metrics/{id}`.
* **Core Engine** – Scheduler topologically executes nodes; each node is an `async def run()` coroutine streaming artefacts.
* **Plug‑ins** – Each directory under `plugins/` with `manifest.yaml` declaring backend class and optional UI component.

## Data Contracts

| Artefact | Python type | Serialized |
|----------|-------------|------------|
| Dataset | Arrow or list[dict] | .jsonl / .parquet |
| Model   | transformers.PreTrainedModel | .safetensors |
| Adapter | peft.LoraModel | .pt |
| GGUF    | bytes | .gguf |

## Deployment

* **Local dev** – `./scripts/dev.sh` → watchfiles + uvicorn.
* **Docker** – `docker compose -f docker/gpu.yml up`.
* **Kubernetes** – Helm chart TBD (see `deploy/`).

Security: API key via `LLMTRAINER_API_KEY`, CORS disabled by default.
