See README section **Quick start** plus graph walkthrough at docs/WORKFLOW_EXAMPLES.md
